"""Control Tuya smart plug via TinyTuya local API."""

from __future__ import annotations

import logging
from typing import Any

import tinytuya

from app.config import Settings

logger = logging.getLogger(__name__)


class TuyaController:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._device: tinytuya.Device | None = None
        self._last_state: bool | None = None

        if settings.tuya_configured:
            self._device = tinytuya.OutletDevice(
                dev_id=settings.tuya_device_id,
                address=settings.tuya_ip,
                local_key=settings.tuya_local_key,
                version=settings.tuya_version,
            )
            self._device.set_socketPersistent(True)
            self._device.set_socketRetryLimit(3)
            self._device.set_socketTimeout(5)
            logger.info("Tuya plug configured at %s", settings.tuya_ip)
        else:
            logger.warning("Tuya plug not configured - plug control disabled")

    @property
    def last_state(self) -> bool | None:
        return self._last_state

    def get_status(self) -> dict[str, Any]:
        if not self._device:
            return {"configured": False, "online": False}
        try:
            data = self._device.status()
            if not data or "dps" not in data:
                return {"configured": True, "online": False, "raw": data}
            dp = str(self._settings.tuya_switch_dp)
            state = bool(data["dps"].get(dp, data["dps"].get(int(dp))))
            self._last_state = state
            return {
                "configured": True,
                "online": True,
                "on": state,
                "power_w": data["dps"].get("19"),
                "voltage_v": data["dps"].get("20"),
            }
        except Exception as exc:
            logger.error("Tuya status failed: %s", exc)
            return {"configured": True, "online": False, "error": str(exc)}

    def set_plug(self, on: bool) -> bool:
        if not self._device:
            logger.warning("Cannot set plug - not configured")
            return False
        try:
            result = self._device.set_status(on, self._settings.tuya_switch_dp)
            if result and "Err" in result:
                logger.error("Tuya set_plug error: %s", result)
                return False
            self._last_state = on
            logger.info("Plug set to %s", "ON" if on else "OFF")
            return True
        except Exception as exc:
            logger.error("Tuya set_plug failed: %s", exc)
            return False