"""Charger Monitor - FastAPI server with WebRTC, Gemini AI, and Tuya plug."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from app.ai_analyzer import AIAnalyzer
from app.analyzer_loop import AnalyzerLoop
from app.config import load_settings
from app.tuya_controller import TuyaController
from app.webrtc_handler import WebRTCHandler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).resolve().parent / "static"

settings = load_settings()
webrtc_handler = WebRTCHandler()
tuya_controller = TuyaController(settings)
ai_analyzer = AIAnalyzer(settings)
analyzer_loop = AnalyzerLoop(settings, webrtc_handler, ai_analyzer, tuya_controller)


class OfferRequest(BaseModel):
    sdp: str
    type: str


class IceCandidateRequest(BaseModel):
    candidate: str | None = None
    sdpMid: str | None = None
    sdpMLineIndex: int | None = None


@asynccontextmanager
async def lifespan(_app: FastAPI):
    analyzer_loop.start()
    logger.info("Charger Monitor started on port %s", settings.port)
    yield
    await analyzer_loop.stop()
    await webrtc_handler.close_all()


app = FastAPI(title="Charger Monitor", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.post("/api/offer")
async def api_offer(body: OfferRequest) -> dict[str, str]:
    try:
        answer = await webrtc_handler.handle_offer(body.sdp, body.type)
        return answer
    except Exception as exc:
        logger.error("WebRTC offer failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/api/ice-candidate")
async def api_ice_candidate(body: IceCandidateRequest) -> dict[str, bool]:
    try:
        await webrtc_handler.add_ice_candidate(body.model_dump())
        return {"ok": True}
    except Exception as exc:
        logger.warning("ICE candidate failed: %s", exc)
        return {"ok": False}


@app.get("/api/status")
async def api_status() -> dict[str, Any]:
    plug_status = tuya_controller.get_status()
    return {
        "stream": webrtc_handler.state.to_dict(),
        "analysis": analyzer_loop.last_analysis,
        "plug": plug_status,
        "config": {
            "tuya_configured": settings.tuya_configured,
            "ai_provider": settings.ai_provider,
            "ai_configured": settings.ai_configured,
            "analyze_interval_sec": settings.analyze_interval_sec,
        },
    }


@app.post("/api/plug/{action}")
async def api_plug_manual(action: str) -> dict[str, Any]:
    if action not in ("on", "off"):
        raise HTTPException(status_code=400, detail="Use /api/plug/on or /api/plug/off")
    ok = tuya_controller.set_plug(action == "on")
    return {"success": ok, "plug_on": action == "on"}