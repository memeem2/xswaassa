"""Extract JPEG frames from a WebRTC video track."""

from __future__ import annotations

import asyncio
import io
import logging

from aiortc import VideoStreamTrack
from PIL import Image

logger = logging.getLogger(__name__)


async def grab_jpeg(track: VideoStreamTrack, timeout: float = 3.0) -> bytes | None:
    """Grab the freshest frame from the video track and return JPEG bytes."""
    try:
        frame = None
        drain_until = asyncio.get_running_loop().time() + 0.5
        while asyncio.get_running_loop().time() < drain_until:
            try:
                frame = await asyncio.wait_for(track.recv(), timeout=0.1)
            except asyncio.TimeoutError:
                break
        if frame is None:
            frame = await asyncio.wait_for(track.recv(), timeout=timeout)
        ndarray = frame.to_ndarray(format="rgb24")
        image = Image.fromarray(ndarray)
        if image.width > 640:
            image = image.resize((640, int(image.height * 640 / image.width)))
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=80)
        return buffer.getvalue()
    except asyncio.TimeoutError:
        logger.debug("Frame grab timed out")
        return None
    except Exception as exc:
        logger.error("Frame grab failed: %s", exc)
        return None