"""WebRTC peer connection management for phone camera streams."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any

from aiortc import RTCPeerConnection, RTCSessionDescription, VideoStreamTrack
from aiortc import RTCConfiguration
from aiortc.sdp import candidate_from_sdp

from app.frame_buffer import FrameBuffer

logger = logging.getLogger(__name__)

# LAN-only: no STUN/TURN so we get 192.168.x.x host candidates immediately.
LAN_RTC_CONFIG = RTCConfiguration(iceServers=[])


@dataclass
class StreamState:
    peer_connections: set[RTCPeerConnection] = field(default_factory=set)
    video_track: VideoStreamTrack | None = None
    stream_connected: bool = False
    frames_received: int = 0
    connection_state: str = "new"
    ice_state: str = "new"

    def to_dict(self) -> dict[str, Any]:
        return {
            "stream_connected": self.stream_connected,
            "active_peers": len(self.peer_connections),
            "frames_received": self.frames_received,
            "connection_state": self.connection_state,
            "ice_state": self.ice_state,
        }


class WebRTCHandler:
    def __init__(self) -> None:
        self.state = StreamState()
        self._frame_buffer = FrameBuffer()
        self._active_pc: RTCPeerConnection | None = None

    def get_video_track(self) -> VideoStreamTrack | None:
        return self.state.video_track

    def get_frame_buffer(self) -> FrameBuffer:
        return self._frame_buffer

    def _refresh_stream_state(self) -> None:
        buffer = self._frame_buffer
        self.state.frames_received = buffer.frames_received
        if buffer.frames_received > 0:
            self.state.stream_connected = True
        elif self.state.video_track is not None and buffer.active:
            self.state.stream_connected = True

    async def _on_video_track(self, track: VideoStreamTrack) -> None:
        logger.info("Video track received")
        self.state.video_track = track
        await self._frame_buffer.start(track)
        self.state.stream_connected = True
        logger.info("Frame buffer started")

    async def add_ice_candidate(self, payload: dict[str, Any]) -> None:
        pc = self._active_pc
        if pc is None:
            logger.debug("Ignoring ICE candidate (no active peer)")
            return

        cand_str = payload.get("candidate")
        if not cand_str:
            await pc.addIceCandidate(None)
            return

        candidate = candidate_from_sdp(cand_str)
        candidate.sdpMid = payload.get("sdpMid")
        candidate.sdpMLineIndex = payload.get("sdpMLineIndex")
        await pc.addIceCandidate(candidate)
        logger.debug("Added remote ICE candidate")

    async def handle_offer(self, sdp: str, sdp_type: str) -> dict[str, str]:
        if self.state.peer_connections:
            logger.info("Closing existing stream for new connection")
            await self.close_all()

        offer = RTCSessionDescription(sdp=sdp, type=sdp_type)
        pc = RTCPeerConnection(configuration=LAN_RTC_CONFIG)
        self._active_pc = pc
        self.state.peer_connections.add(pc)

        @pc.on("track")
        def on_track(track: VideoStreamTrack) -> None:
            if track.kind == "video":
                asyncio.create_task(self._on_video_track(track))

        @pc.on("connectionstatechange")
        async def on_connectionstatechange() -> None:
            self.state.connection_state = pc.connectionState
            logger.info("WebRTC state: %s", pc.connectionState)
            if pc.connectionState == "connected":
                self.state.stream_connected = True
            if pc.connectionState in ("failed", "closed", "disconnected"):
                if pc in self.state.peer_connections:
                    await pc.close()
                    self.state.peer_connections.discard(pc)
                if pc is self._active_pc:
                    self._active_pc = None
                if not self.state.peer_connections:
                    await self._frame_buffer.stop()
                    self.state.video_track = None
                    self.state.stream_connected = False
                    self.state.frames_received = 0
                    self.state.connection_state = "closed"
                    self.state.ice_state = "closed"

        @pc.on("iceconnectionstatechange")
        async def on_iceconnectionstatechange() -> None:
            self.state.ice_state = pc.iceConnectionState
            logger.info("ICE state: %s", pc.iceConnectionState)
            if pc.iceConnectionState in ("connected", "completed"):
                self.state.stream_connected = True
            self._refresh_stream_state()

        await pc.setRemoteDescription(offer)
        answer = await pc.createAnswer()
        await pc.setLocalDescription(answer)

        # Wait for all LAN host candidates before returning answer to phone.
        for _ in range(100):
            if pc.iceGatheringState == "complete":
                break
            await asyncio.sleep(0.1)
        else:
            logger.warning("ICE gathering still in progress after 10s")

        self._refresh_stream_state()
        return {
            "sdp": pc.localDescription.sdp,
            "type": pc.localDescription.type,
        }

    async def close_all(self) -> None:
        await self._frame_buffer.stop()
        for pc in list(self.state.peer_connections):
            await pc.close()
        self.state.peer_connections.clear()
        self._active_pc = None
        self.state.video_track = None
        self.state.stream_connected = False
        self.state.frames_received = 0
        self.state.connection_state = "closed"
        self.state.ice_state = "closed"