"""Load configuration from env file, environment variables, or devices.json."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
PROJECT_DIR = APP_DIR.parent

CONFIG_SEARCH_PATHS = [
    Path("/etc/charger-monitor/config.env"),
    PROJECT_DIR / "config.env",
    PROJECT_DIR / "config" / "config.env",
]

DEVICES_SEARCH_PATHS = [
    Path("/etc/charger-monitor/devices.json"),
    PROJECT_DIR / "devices.json",
]


def _strip_quotes(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
        return value[1:-1]
    return value


def load_env_file(path: Path) -> dict[str, str]:
    env: dict[str, str] = {}
    if not path.is_file():
        return env
    with path.open(encoding="utf-8") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            key, sep, value = line.partition("=")
            if not sep:
                continue
            env[key.strip()] = _strip_quotes(value)
    return env


def load_devices_file(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    with path.open(encoding="utf-8") as handle:
        devices = json.load(handle)
    if not devices:
        return {}
    device = devices[0]
    result = {
        "TUYA_DEVICE_ID": device.get("id", ""),
        "TUYA_LOCAL_KEY": device.get("key", ""),
        "TUYA_IP": device.get("ip", ""),
    }
    if device.get("version"):
        result["TUYA_VERSION"] = str(device["version"])
    return result


def _parse_float(value: str, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _parse_int(value: str, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    tuya_device_id: str
    tuya_local_key: str
    tuya_ip: str
    tuya_version: float
    tuya_switch_dp: int
    ai_provider: str
    openrouter_api_key: str
    openrouter_model: str
    gemini_api_key: str
    gemini_model: str
    analyze_interval_sec: float
    host: str
    port: int
    ssl_cert: str
    ssl_key: str

    @property
    def tuya_configured(self) -> bool:
        return bool(self.tuya_device_id and self.tuya_local_key and self.tuya_ip)

    @property
    def gemini_configured(self) -> bool:
        return bool(self.gemini_api_key)

    @property
    def ai_configured(self) -> bool:
        if self.ai_provider == "openrouter":
            return bool(self.openrouter_api_key)
        if self.ai_provider == "gemini":
            return bool(self.gemini_api_key)
        return False


def load_settings() -> Settings:
    merged: dict[str, str] = {}

    for path in CONFIG_SEARCH_PATHS:
        merged.update(load_env_file(path))

    for path in DEVICES_SEARCH_PATHS:
        file_values = load_devices_file(path)
        for key, value in file_values.items():
            if value and not merged.get(key):
                merged[key] = value

    for key, value in os.environ.items():
        if value:
            merged[key] = value

    return Settings(
        tuya_device_id=merged.get("TUYA_DEVICE_ID", ""),
        tuya_local_key=merged.get("TUYA_LOCAL_KEY", ""),
        tuya_ip=merged.get("TUYA_IP", ""),
        tuya_version=_parse_float(merged.get("TUYA_VERSION", "3.4"), 3.4),
        tuya_switch_dp=_parse_int(merged.get("TUYA_SWITCH_DP", "1"), 1),
        ai_provider=merged.get("AI_PROVIDER", "openrouter").lower(),
        openrouter_api_key=merged.get("OPENROUTER_API_KEY", ""),
        openrouter_model=merged.get(
            "OPENROUTER_MODEL", "google/gemma-4-31b-it:free"
        ),
        gemini_api_key=merged.get("GEMINI_API_KEY", ""),
        gemini_model=merged.get("GEMINI_MODEL", "gemini-2.0-flash-lite"),
        analyze_interval_sec=_parse_float(merged.get("ANALYZE_INTERVAL_SEC", "10"), 10.0),
        host=merged.get("HOST", "0.0.0.0"),
        port=_parse_int(merged.get("PORT", "8443"), 8443),
        ssl_cert=merged.get("SSL_CERT", "/etc/charger-monitor/ssl/cert.pem"),
        ssl_key=merged.get("SSL_KEY", "/etc/charger-monitor/ssl/key.pem"),
    )