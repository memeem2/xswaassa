/* Charger Monitor - phone camera WebRTC client */

const preview = document.getElementById("preview");
const btnStart = document.getElementById("btn-start");
const btnFlip = document.getElementById("btn-flip");
const btnStop = document.getElementById("btn-stop");
const statusStream = document.getElementById("status-stream");
const statusAi = document.getElementById("status-ai");
const statusPlug = document.getElementById("status-plug");
const statusReason = document.getElementById("status-reason");

let facingMode = "environment";
let localStream = null;
let peerConnection = null;
let statusTimer = null;

// LAN-only: no STUN so phone uses 192.168.x.x host candidates directly.
const ICE_SERVERS = [];

function setButtons(streaming) {
  btnStart.disabled = streaming;
  btnFlip.disabled = !streaming;
  btnStop.disabled = !streaming;
}

async function sendIceCandidate(candidate) {
  try {
    await fetch("/api/ice-candidate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(
        candidate
          ? {
              candidate: candidate.candidate,
              sdpMid: candidate.sdpMid,
              sdpMLineIndex: candidate.sdpMLineIndex,
            }
          : { candidate: null }
      ),
    });
  } catch (err) {
    console.debug("ICE send failed:", err);
  }
}

async function waitForIceGathering(pc, timeoutMs = 10000) {
  if (pc.iceGatheringState === "complete") return;
  await new Promise((resolve) => {
    const timer = setTimeout(resolve, timeoutMs);
    const check = () => {
      if (pc.iceGatheringState === "complete") {
        clearTimeout(timer);
        pc.removeEventListener("icegatheringstatechange", check);
        resolve();
      }
    };
    pc.addEventListener("icegatheringstatechange", check);
  });
}

async function getCameraStream() {
  const constraints = {
    audio: false,
    video: {
      facingMode: { ideal: facingMode },
      width: { ideal: 640, max: 1280 },
      height: { ideal: 480, max: 720 },
      frameRate: { ideal: 15, max: 24 },
    },
  };

  if (localStream) {
    localStream.getTracks().forEach((track) => track.stop());
    localStream = null;
  }

  localStream = await navigator.mediaDevices.getUserMedia(constraints);
  preview.srcObject = localStream;
  return localStream;
}

async function replaceVideoTrack() {
  if (!peerConnection || !localStream) return;
  const newTrack = localStream.getVideoTracks()[0];
  const sender = peerConnection
    .getSenders()
    .find((s) => s.track && s.track.kind === "video");
  if (sender && newTrack) {
    await sender.replaceTrack(newTrack);
  }
}

async function startStream() {
  try {
    await getCameraStream();

    peerConnection = new RTCPeerConnection({ iceServers: ICE_SERVERS });

    localStream.getTracks().forEach((track) => {
      peerConnection.addTrack(track, localStream);
    });

    peerConnection.onicecandidate = (event) => {
      sendIceCandidate(event.candidate);
    };

    peerConnection.onconnectionstatechange = () => {
      const state = peerConnection.connectionState;
      if (state === "connected") {
        statusStream.textContent = "Connected";
        statusStream.className = "value connected";
      } else if (state === "connecting") {
        statusStream.textContent = "Connecting...";
        statusStream.className = "value";
      } else if (state === "failed" || state === "disconnected" || state === "closed") {
        statusStream.textContent = state;
        statusStream.className = "value off";
      }
    };

    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);

    await waitForIceGathering(peerConnection, 10000);

    const response = await fetch("/api/offer", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sdp: peerConnection.localDescription.sdp,
        type: peerConnection.localDescription.type,
      }),
    });

    if (!response.ok) {
      throw new Error(`Server error: ${response.status}`);
    }

    const answer = await response.json();
    await peerConnection.setRemoteDescription(answer);

    setButtons(true);
    startStatusPolling();
  } catch (err) {
    console.error("Start stream failed:", err);
    alert("Could not start stream: " + err.message + "\n\nMake sure you opened https:// and allowed camera access.");
    await stopStream();
  }
}

async function stopStream() {
  stopStatusPolling();

  if (peerConnection) {
    peerConnection.close();
    peerConnection = null;
  }

  if (localStream) {
    localStream.getTracks().forEach((track) => track.stop());
    localStream = null;
  }

  preview.srcObject = null;
  setButtons(false);
  statusStream.textContent = "Disconnected";
  statusStream.className = "value";
}

async function flipCamera() {
  if (!localStream) return;
  facingMode = facingMode === "user" ? "environment" : "user";
  try {
    await getCameraStream();
    await replaceVideoTrack();
  } catch (err) {
    console.error("Flip camera failed:", err);
    facingMode = facingMode === "user" ? "environment" : "user";
    alert("Could not flip camera: " + err.message);
  }
}

async function pollStatus() {
  try {
    const response = await fetch("/api/status");
    if (!response.ok) return;
    const data = await response.json();

    const localConnected =
      peerConnection && peerConnection.connectionState === "connected";
    if (data.stream.stream_connected || localConnected) {
      statusStream.textContent = "Connected";
      statusStream.className = "value connected";
    } else if (peerConnection && peerConnection.connectionState === "connecting") {
      statusStream.textContent = "Connecting...";
      statusStream.className = "value";
    }

    const analysis = data.analysis || {};
    if (analysis.phone_on_charger === true) {
      statusAi.textContent = "Phone ON charger";
      statusAi.className = "value on";
    } else if (analysis.phone_on_charger === false) {
      statusAi.textContent = "Phone NOT on charger";
      statusAi.className = "value off";
    } else {
      statusAi.textContent = "Analyzing...";
      statusAi.className = "value";
    }

    const plugOn = analysis.plug_on ?? data.plug?.on;
    if (plugOn === true) {
      statusPlug.textContent = "ON";
      statusPlug.className = "value on";
    } else if (plugOn === false) {
      statusPlug.textContent = "OFF";
      statusPlug.className = "value off";
    }

    if (analysis.reason) {
      statusReason.textContent = analysis.reason;
    }
  } catch (err) {
    console.debug("Status poll failed:", err);
  }
}

function startStatusPolling() {
  stopStatusPolling();
  pollStatus();
  statusTimer = setInterval(pollStatus, 3000);
}

function stopStatusPolling() {
  if (statusTimer) {
    clearInterval(statusTimer);
    statusTimer = null;
  }
}

btnStart.addEventListener("click", startStream);
btnStop.addEventListener("click", stopStream);
btnFlip.addEventListener("click", flipCamera);

setButtons(false);