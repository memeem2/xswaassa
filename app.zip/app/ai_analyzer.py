"""Analyze camera frames with OpenRouter or Gemini vision APIs."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import re
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

from app.config import Settings

logger = logging.getLogger(__name__)

PROMPT = """You are monitoring a phone charger setup.
Look at the image carefully.

Question: Is a smartphone physically plugged into the charger cable right now?
The phone must be connected to the cable/charger - not just nearby.

Reply ONLY with valid JSON, no markdown:
{"phone_on_charger": true, "confidence": 0.95, "reason": "brief explanation"}"""


@dataclass(frozen=True)
class AnalysisResult:
    phone_on_charger: bool
    confidence: float
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "phone_on_charger": self.phone_on_charger,
            "confidence": self.confidence,
            "reason": self.reason,
        }


def _extract_json(text: str) -> dict[str, Any] | None:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{[^{}]*\}", text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except json.JSONDecodeError:
                return None
    return None


def _parse_result(parsed: dict[str, Any] | None, raw_text: str) -> AnalysisResult | None:
    if not parsed:
        logger.error("AI returned unparseable response: %s", raw_text[:200])
        return None
    return AnalysisResult(
        phone_on_charger=bool(parsed.get("phone_on_charger", False)),
        confidence=float(parsed.get("confidence", 0.5)),
        reason=str(parsed.get("reason", "No reason given")),
    )


class AIAnalyzer:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._gemini_client = None

        if settings.ai_configured:
            if settings.ai_provider == "gemini":
                try:
                    from google import genai

                    self._gemini_client = genai.Client(api_key=settings.gemini_api_key)
                    logger.info("AI provider: Gemini (%s)", settings.gemini_model)
                except Exception as exc:
                    logger.error("Failed to init Gemini: %s", exc)
            elif settings.ai_provider == "openrouter":
                logger.info(
                    "AI provider: OpenRouter (%s)",
                    settings.openrouter_model,
                )
        else:
            logger.warning(
                "AI not configured - set OPENROUTER_API_KEY (recommended) in config.env"
            )

    async def analyze(self, jpeg_bytes: bytes) -> AnalysisResult | None:
        if not self._settings.ai_configured:
            return None
        if self._settings.ai_provider == "openrouter":
            return await self._analyze_openrouter(jpeg_bytes)
        if self._settings.ai_provider == "gemini":
            return await self._analyze_gemini(jpeg_bytes)
        logger.error("Unknown AI provider: %s", self._settings.ai_provider)
        return None

    async def _analyze_openrouter(self, jpeg_bytes: bytes) -> AnalysisResult | None:
        def _call() -> str:
            b64 = base64.b64encode(jpeg_bytes).decode("ascii")
            payload = {
                "model": self._settings.openrouter_model,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": PROMPT},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{b64}",
                                },
                            },
                        ],
                    }
                ],
                "temperature": 0.1,
                "max_tokens": 256,
            }
            req = urllib.request.Request(
                "https://openrouter.ai/api/v1/chat/completions",
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Authorization": f"Bearer {self._settings.openrouter_api_key}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://charger-monitor.local",
                    "X-Title": "Charger Monitor",
                },
                method="POST",
            )
            try:
                with urllib.request.urlopen(req, timeout=60) as resp:
                    body = json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                err_body = exc.read().decode("utf-8", errors="replace")
                raise RuntimeError(f"OpenRouter HTTP {exc.code}: {err_body[:300]}") from exc
            choices = body.get("choices") or []
            if not choices:
                raise RuntimeError(f"OpenRouter empty response: {body}")
            return str(choices[0]["message"]["content"])

        try:
            text = await asyncio.to_thread(_call)
            return _parse_result(_extract_json(text), text)
        except Exception as exc:
            logger.error("OpenRouter analysis failed: %s", exc)
            return None

    async def _analyze_gemini(self, jpeg_bytes: bytes) -> AnalysisResult | None:
        if not self._gemini_client:
            return None
        try:
            from google.genai import types

            def _call() -> Any:
                return self._gemini_client.models.generate_content(
                    model=self._settings.gemini_model,
                    contents=[
                        PROMPT,
                        types.Part.from_bytes(data=jpeg_bytes, mime_type="image/jpeg"),
                    ],
                    config=types.GenerateContentConfig(
                        temperature=0.1,
                        max_output_tokens=256,
                    ),
                )

            response = await asyncio.to_thread(_call)
            text = (response.text or "").strip()
            return _parse_result(_extract_json(text), text)
        except Exception as exc:
            logger.error("Gemini analysis failed: %s", exc)
            return None