"""Background video frame consumer for WebRTC tracks."""

from __future__ import annotations

import asyncio
import io
import logging

from aiortc import VideoStreamTrack
from av import VideoFrame
from PIL import Image

logger = logging.getLogger(__name__)


class FrameBuffer:
    def __init__(self) -> None:
        self._latest: VideoFrame | None = None
        self._task: asyncio.Task | None = None
        self._track: VideoStreamTrack | None = None
        self._frames_received: int = 0

    @property
    def frames_received(self) -> int:
        return self._frames_received

    @property
    def active(self) -> bool:
        return self._task is not None and not self._task.done()

    async def start(self, track: VideoStreamTrack) -> None:
        await self.stop()
        self._track = track
        self._latest = None
        self._frames_received = 0
        self._task = asyncio.create_task(self._consume(), name="frame-buffer")
        logger.info("Frame buffer started")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        self._track = None
        self._latest = None

    async def _consume(self) -> None:
        track = self._track
        if track is None:
            return
        try:
            while True:
                frame = await track.recv()
                self._latest = frame
                self._frames_received += 1
                if self._frames_received == 1:
                    logger.info("First video frame received")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning("Frame buffer stopped: %s", exc)

    def grab_jpeg(self) -> bytes | None:
        frame = self._latest
        if frame is None:
            return None
        try:
            ndarray = frame.to_ndarray(format="rgb24")
            image = Image.fromarray(ndarray)
            if image.width > 640:
                image = image.resize((640, int(image.height * 640 / image.width)))
            buffer = io.BytesIO()
            image.save(buffer, format="JPEG", quality=80)
            return buffer.getvalue()
        except Exception as exc:
            logger.error("JPEG encode failed: %s", exc)
            return None