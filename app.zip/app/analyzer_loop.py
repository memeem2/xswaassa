"""Background loop: grab frames, analyze with AI, control Tuya plug."""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any

from app.ai_analyzer import AIAnalyzer, AnalysisResult
from app.config import Settings
from app.tuya_controller import TuyaController
from app.webrtc_handler import WebRTCHandler

logger = logging.getLogger(__name__)


class AnalyzerLoop:
    def __init__(
        self,
        settings: Settings,
        webrtc: WebRTCHandler,
        analyzer: AIAnalyzer,
        tuya: TuyaController,
    ) -> None:
        self._settings = settings
        self._webrtc = webrtc
        self._analyzer = analyzer
        self._tuya = tuya
        self._task: asyncio.Task | None = None
        self._last_analysis: dict[str, Any] = {
            "phone_on_charger": None,
            "confidence": None,
            "reason": "Waiting for stream...",
            "timestamp": None,
            "plug_on": None,
        }

    @property
    def last_analysis(self) -> dict[str, Any]:
        return dict(self._last_analysis)

    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._run(), name="analyzer-loop")
            logger.info(
                "Analyzer loop started (interval=%ss)",
                self._settings.analyze_interval_sec,
            )

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def _run(self) -> None:
        while True:
            try:
                await self._tick()
            except Exception as exc:
                logger.error("Analyzer tick error: %s", exc)
            await asyncio.sleep(self._settings.analyze_interval_sec)

    async def _tick(self) -> None:
        buffer = self._webrtc.get_frame_buffer()
        self._webrtc.state.frames_received = buffer.frames_received
        if buffer.frames_received > 0 or (buffer.active and self._webrtc.state.video_track):
            self._webrtc.state.stream_connected = True

        if not self._webrtc.state.stream_connected:
            self._last_analysis["reason"] = "No camera stream active"
            return

        if buffer.frames_received == 0:
            self._last_analysis["reason"] = "Waiting for first video frame..."
            return

        jpeg = await asyncio.to_thread(buffer.grab_jpeg)
        if not jpeg:
            self._last_analysis["reason"] = "Could not grab frame"
            return

        result: AnalysisResult | None = await self._analyzer.analyze(jpeg)
        if result is None:
            self._last_analysis["reason"] = "AI analysis failed (check OPENROUTER_API_KEY)"
            return

        plug_on = result.phone_on_charger
        plug_ok = self._tuya.set_plug(plug_on)

        self._last_analysis = {
            "phone_on_charger": result.phone_on_charger,
            "confidence": result.confidence,
            "reason": result.reason,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "plug_on": plug_on if plug_ok else self._tuya.last_state,
            "plug_command_ok": plug_ok,
        }
        logger.info(
            "AI: phone_on_charger=%s (%.0f%%) -> plug %s",
            result.phone_on_charger,
            result.confidence * 100,
            "ON" if plug_on else "OFF",
        )